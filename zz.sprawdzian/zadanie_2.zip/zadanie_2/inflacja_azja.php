<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Roczniki</title>
  <link rel="icon" href="fa fa-thermometer-empty" type="image/x-icon">

</head>

<body>
<?php
$json="Armenia":"2,5%","Liban":"16,1%","Mongolia":"9,6%";
?>
<fieldset>
    <code>
        <?php
        echo $json;
        ?>
    </code>
</fieldset>

</body>

</html>